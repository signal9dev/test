from iconservice import Address

EOA_ZERO = Address.from_string('hx' + '0' * 40) #'hx0000000000000000000000000000000000000000'

TAG = "Donation337"
SYMBOL = "337"
DECIMALS = 6

BEFORE = -2
CANCEL = -1
DOING = 0
DONE = 1
CLOSED = 2

LOCK = 0
UNLOCK = 1

BID_RATE = 3
