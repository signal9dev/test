from . import (
    TAG,
    SYMBOL,
    DECIMALS,
    EOA_ZERO,
    BEFORE,
    CANCEL,
    DOING,
    DONE,
    CLOSED,
    LOCK,
    UNLOCK,
    BID_RATE,
)
from iconservice import *


class Donation337(IconScoreBase):

    @eventlog(indexed=2)
    def AddManager(self, _sender: Address, _addr: Address):
        pass

    @eventlog(indexed=3)
    def Mint(self, _sender: Address, _owner: Address, _amount: int, _balance: int):
        pass

    @eventlog(indexed=2)
    def Burn(self, _owner: Address, _amount: int, _balance: int):
        pass

    @eventlog(indexed=3)
    def Deposit(self, _sender: Address, _order_id: str, _owner: Address, _balance: int, _type: bytes, _data: bytes):
        pass

    @eventlog(indexed=3)
    def RequestWithdraw(self, _sender: Address, _order_id: str, _owner: Address, _balance: int, _data: bytes):
        pass

    @eventlog(indexed=3)
    def ConfirmWithdraw(self, _sender: Address, _order_id: str, _owner: Address, _balance: int):
        pass

    @eventlog(indexed=3)
    def AddGoods(self, _sender: Address, _goods: str, _name: str, _url: str, _hash: str, _data: bytes):
        pass

    @eventlog(indexed=3)
    def UpdateGoods(self, _sender: Address, _goods: str, _name: str, _url: str, _hash: str, _data: bytes):
        pass

    @eventlog(indexed=3)
    def AddAuction(self, _sender: Address, _goods: str, _auction: str, _price: int, _url: str, _hash: str, _data: bytes):
        pass

    @eventlog(indexed=3)
    def BidAuction(self, _sender: Address, _goods: str, _auction: str, _price: int, _data: bytes):
        pass

    @eventlog(indexed=3)
    def CloseAuction(self, _sender: Address, _goods: str, _auction: str, _price: int, _owner: Address):
        pass

    @eventlog(indexed=3)
    def ConfirmAuction(self, _sender: Address, _goods: str, _auction: str, _price: int, _owner: Address, _data: bytes):
        pass

    @eventlog(indexed=3)
    def CancelAuction(self, _sender: Address, _goods: str, _auction: str, _price: int, _owner: Address, _data: bytes):
        pass

    @eventlog(indexed=2)
    def CalculateFee(self, _sender: Address, _amount: int):
        pass

    def __init__(self, db: IconScoreDatabase) -> None:
        super().__init__(db)
        # manager address
        self._manager = VarDB('MANAGER', db, value_type=Address)

        # token total supply
        self._total_supply = VarDB('TOTAL_SUPPLY', db, value_type=int)

        # balance
        self._balance = DictDB('BALANCES', db, value_type=int)

        # lock balance
        self._lock_balance = DictDB('LOCK_BALANCES', db, value_type=int)

        # lock order data
        self._lock_info = DictDB('lock_info', db, value_type=str)
        self._lock_amount = DictDB('lock_amount', db, value_type=int)
        self._lock_owner = DictDB('lock_owner', db, value_type=Address)
        self._lock_stat = DictDB('lock_stat', db, value_type=bool)

        # deposit information
        self._deposit_balance = DictDB('deposit_balance', db, value_type=int)
        self._deposit_owner = DictDB('deposit_owner', db, value_type=Address)

        # withdraw information
        self._withdraw_balance = DictDB('withdraw_balance', db, value_type=int)
        self._withdraw_owner = DictDB('withdraw_owner', db, value_type=Address)
        self._withdraw_stat = DictDB('withdraw_stat', db, value_type=bool)

        # goods & auction information
        self._goods_auction = DictDB('goods_auction', db, value_type=str)
        self._goods_name = DictDB('goods_name', db, value_type=str)
        self._goods_url = DictDB('goods_url', db, value_type=str)
        self._goods_hash = DictDB('goods_hash', db, value_type=str)
        self._goods_bid = DictDB('goods_bid', db, value_type=int)
        self._goods_state = DictDB('goods_state', db, value_type=int)
        self._goods_owner = DictDB('goods_owner', db, value_type=Address)
        self._goods_register = DictDB('goods_register', db, value_type=Address)
        self._goods_confirm = DictDB('goods_confirm', db, value_type=Address)
        self._goods_add_block = DictDB('goods_add_block', db, value_type=int)
        self._goods_start_block = DictDB('goods_start_block', db, value_type=int)
        self._goods_end_block = DictDB('goods_end_block', db, value_type=int)

    def on_install(self) -> None:
        super().on_install()

        self._total_supply.set(0)

        # default
        self._manager.set(self.msg.sender)

    def on_update(self) -> None:
        super().on_update()

    def _check_permission(self, _addr: Address):
        manager = self._manager.get()
        if self.msg.sender != manager:
            revert('no execute permission')

    def _check_balance(self, _owner: Address, _amount: int):
        balance = self._lock_balance[_owner]
        if balance < _amount:
            revert('low balance')

    def _current_balance(self, _owner: Address) -> int:
        return self._balance[_owner] - self._lock_balance[_owner]

    def _calc_balance(self, _sender: Address, _price: int):
        balance = self._current_balance(_sender)
        if balance < 1:
            revert('not enough assets to bid in the auction')
        elif (balance * BID_RATE) < _price:
            revert('not enough assets to bid in the auction')

    def _balance_lock(self, _order_id: str, _owner: Address, _price: int):
        self._lock_balance[_owner] = self._lock_balance[_owner] + _price

        self._lock_info[f'{_order_id}-{_owner}'] = _order_id
        self._lock_amount[f'{_order_id}-{_owner}'] = _price
        self._lock_owner[f'{_order_id}-{_owner}'] = _owner
        self._lock_stat[f'{_order_id}-{_owner}'] = LOCK

    def _balance_unlock(self, _order_id: str, _owner: Address):
        _price = self._lock_amount[f'{_order_id}-{_owner}']
        self._lock_stat[f'{_order_id}-{_owner}'] = UNLOCK

        self._lock_balance[_owner] = self._lock_balance[_owner] - _price

    def _paid(self, _owner: Address, _price: int):
        _manager = self._manager.get()
        self._balance[_owner] = self._balance[_owner] - _price
        self._balance[_manager] = self._balance[_manager] + _price

    def _mint(self, _owner: Address, _amount: int) -> int:
        if _amount < 1:
            revert('mint amount cannot be less than 1')

        self._total_supply.set(self._total_supply.get() + _amount)
        self._balance[_owner] += _amount
        return self._balance[_owner]

    def _burn(self, _owner: Address, _amount: int):
        # check balance
        self._check_balance(_owner, _amount)

        if _amount < 1:
            revert('burn amount cannot be less than 1')

        self._total_supply.set(self._total_supply.get() - _amount)
        self._balance[_owner] -= _amount
        self._lock_balance[_owner] -= _amount

    @external(readonly=True)
    def name(self) -> str:
        return TAG

    @external(readonly=True)
    def symbol(self) -> str:
        return SYMBOL

    @external(readonly=True)
    def decimals(self) -> int:
        return DECIMALS

    @external(readonly=True)
    def totalSupply(self) -> int:
        return self._total_supply.get()

    @external(readonly=True)
    def balanceOf(self, _owner: Address) -> int:
        return self._balance[_owner]

    @external(readonly=True)
    def lockBalanceOf(self, _owner: Address) -> int:
        return self._lock_balance[_owner]

    @external(readonly=True)
    def currentBalanceOf(self, _owner: Address) -> int:
        return self._current_balance(_owner)

    @external(readonly=True)
    def manager(self) -> Address:
        return self._manager.get()

    @external
    def addManager(self, _addr: Address):
        # fee sharing
        self.set_fee_sharing_proportion(100)

        # check permission
        self._check_permission(self.msg.sender)

        self._manager.set(_addr)

        # Event logging
        self.AddManager(self.msg.sender, _addr)

    @external
    def deposit(self, _order_id: str, _owner: Address, _balance: int, _type: bytes, _data: bytes):
        # fee sharing
        self.set_fee_sharing_proportion(100)

        # check permission
        self._check_permission(self.msg.sender)

        if self._deposit_balance[_order_id] \
                or self._deposit_owner[_order_id]:
            revert('duplicate order id')

        self._deposit_balance[_order_id] = _balance
        self._deposit_owner[_order_id] = _owner

        self._mint(_owner, _balance)

        # Event logging
        self.Deposit(self.msg.sender, _order_id, _owner, _balance, _type, _data)

    @external
    def requestWithdraw(self, _order_id: str, _owner: Address, _balance: int, _data: bytes):
        # fee sharing
        self.set_fee_sharing_proportion(100)

        if _balance < 1:
            revert('withdraw balance cannot be less than 1')

        if not self._withdraw_owner[_order_id] is None:
            revert('can not found order id')

        self._withdraw_balance[_order_id] = _balance
        self._withdraw_owner[_order_id] = _owner
        self._withdraw_stat[_order_id] = False

        self._balance_lock(_order_id, _owner, _balance)

        # Event logging
        self.RequestWithdraw(self.msg.sender, _order_id, _owner, _balance, _data)

    @external(readonly=True)
    def withdraw(self, _order_id: str) -> dict:
        response = dict()

        response["balance"] = self._withdraw_balance[_order_id]
        response["owner"] = self._withdraw_owner[_order_id]
        response["stat"] = self._withdraw_stat[_order_id]
        return response

    @external
    def confirmWithdraw(self, _order_id: str, _owner: Address):
        # fee sharing
        self.set_fee_sharing_proportion(100)

        # check permission
        self._check_permission(self.msg.sender)

        if self._withdraw_owner[_order_id] is None:
            revert('can not found order id')

        if self._withdraw_stat[_order_id]:
            revert('already withdrawn order id')

        owner = self._withdraw_owner[_order_id]
        if not _owner == owner:
            revert('invalid withdraw owner address')

        _balance = self._withdraw_balance[_order_id]
        self._withdraw_stat[_order_id] = True
        self._burn(owner, _balance)

        # Event logging
        self.ConfirmWithdraw(self.msg.sender, _order_id, owner, _balance)

    @external
    def addGoods(self, _goods: str, _name: str, _url: str, _hash: str, _data: bytes):
        # fee sharing
        self.set_fee_sharing_proportion(100)

        # check permission
        self._check_permission(self.msg.sender)

        if not self._goods_auction[_goods] == '':
            revert('invalid goods id')

        self._goods_auction[_goods] = '-'
        self._goods_name[_goods] = _name
        self._goods_url[_goods] = _url
        self._goods_hash[_goods] = _hash
        self._goods_bid[_goods] = 0
        self._goods_state[_goods] = BEFORE
        self._goods_owner[_goods] = EOA_ZERO
        self._goods_register[_goods] = self.msg.sender
        self._goods_confirm[_goods] = EOA_ZERO
        self._goods_add_block[_goods] = self.block_height
        self._goods_start_block[_goods] = 0
        self._goods_end_block[_goods] = 0

        # Event logging
        self.AddGoods(self.msg.sender, _goods, _name, _url, _hash, _data)

    @external
    def updateGoods(self, _goods: str, _name: str, _url: str, _hash: str, _data: bytes):
        # fee sharing
        self.set_fee_sharing_proportion(100)

        # check permission
        self._check_permission(self.msg.sender)

        if self._goods_auction[_goods] == _goods:
            revert('invalid goods id')

        if not self._goods_auction[_goods] == '-':
            revert('cannot be modified after the auction starts')

        self._goods_name[_goods] = _name
        self._goods_url[_goods] = _url
        self._goods_hash[_goods] = _hash

        self.UpdateGoods(self.msg.sender, _goods, _name, _url, _hash, _data)

    @external(readonly=True)
    def goods(self, _goods: str) -> dict:
        response = dict()
        response["goods"] = _goods
        response["auction"] = self._goods_auction[_goods]
        response["name"] = self._goods_name[_goods]
        response["url"] = self._goods_url[_goods]
        response["hash"] = self._goods_hash[_goods]
        response["bid"] = self._goods_bid[_goods]
        response["state"] = self._goods_state[_goods]
        response["owner"] = self._goods_owner[_goods]
        response["register"] = self._goods_register[_goods]
        response["confirm"] = self._goods_confirm[_goods]
        response["add_block"] = self._goods_add_block[_goods]
        response["start_block"] = self._goods_start_block[_goods]
        response["end_block"] = self._goods_end_block[_goods]
        return response

    @external
    def addAuction(self, _goods: str, _auction: str, _price: int, _data: bytes):
        # fee sharing
        self.set_fee_sharing_proportion(100)

        # check permission
        self._check_permission(self.msg.sender)

        if not self._goods_auction[_goods] == '-':
            revert('invalid goods id')

        self._goods_auction[_goods] = _auction
        self._goods_bid[_goods] = _price
        self._goods_state[_goods] = DOING
        self._goods_start_block[_goods] = self.block_height

        _url = self._goods_url[_goods]
        _hash = self._goods_hash[_goods]

        # Event logging
        self.AddAuction(self.msg.sender, _goods, _auction, _price, _url, _hash, _data)

    def _add_bid(self, _goods: str, _auction: str, _price: int, _data: bytes):
        self._goods_bid[_goods] = _price
        self._goods_owner[_goods] = self.msg.sender

        self._balance_lock(_goods, self.msg.sender, _price)

    def _update_bid(self, _goods: str, _auction: str, _price: int, _data: bytes):
        before_owner = self._goods_owner[_goods]

        if before_owner == self.msg.sender:
            revert('duplicate bid')

        self._balance_unlock(_goods, before_owner)

        self._goods_bid[_goods] = _price
        self._goods_owner[_goods] = self.msg.sender

        self._balance_lock(_goods, self.msg.sender, _price)

    @external
    def bidAuction(self, _goods: str, _auction: str, _price: int, _data: bytes):
        # fee sharing
        self.set_fee_sharing_proportion(100)

        if not self._goods_auction[_goods] == _auction:
            revert('invalid goods id')

        if _price <= self._goods_bid[_goods]:
            revert('asset is too low')

        if not self._goods_state[_goods] == DOING:
            revert('auction is not in doing')

        self._calc_balance(self.msg.sender, _price)

        if self._goods_owner[_goods] == EOA_ZERO:
            self._add_bid(_goods, _auction, _price, _data)
        else:
            self._update_bid(_goods, _auction, _price, _data)

        # Event logging
        self.BidAuction(self.msg.sender, _goods, _auction, _price, _data)

    @external
    def closeAuction(self, _goods: str, _auction: str):
        # fee sharing
        self.set_fee_sharing_proportion(100)

        # check permission
        self._check_permission(self.msg.sender)

        if not self._goods_auction[_goods] == _auction:
            revert('invalid auction id')

        if not self._goods_state[_goods] == DOING:
            revert('auction is not in doing')

        self._goods_state[_goods] = DONE

        _price = self._goods_bid[_goods]
        _owner = self._goods_owner[_goods]

        # Event logging
        self.CloseAuction(self.msg.sender, _goods, _auction, _price, _owner)

    @external
    def confirmAuction(self, _goods: str, _auction: str, _data: bytes):
        # fee sharing
        self.set_fee_sharing_proportion(100)

        # check permission
        self._check_permission(self.msg.sender)

        if not self._goods_auction[_goods] == _auction:
            revert('invalid auction id')

        if not self._goods_state[_goods] == DONE:
            revert('can not change auction status')

        _price = self._goods_bid[_goods]
        _owner = self._goods_owner[_goods]

        if self._balance[_owner] < _price:
            revert('owner balance is too low')

        self._goods_state[_goods] = CLOSED
        self._goods_confirm[_goods] = self.msg.sender
        self._goods_end_block[_goods] = self.block_height

        self._balance_unlock(_goods, _owner)
        self._paid(_owner, _price)

        # Event logging
        self.ConfirmAuction(self.msg.sender, _goods, _auction, _price, _owner, _data)

    @external
    def cancelAuction(self, _goods: str, _auction: str, _data: bytes):
        # fee sharing
        self.set_fee_sharing_proportion(100)

        # check permission
        self._check_permission(self.msg.sender)

        _price = self._goods_bid[_goods]
        _owner = self._goods_owner[_goods]

        if not self._goods_auction[_goods] == _auction:
            revert('invalid auction id')

        if not self._goods_state[_goods] == DOING or self._goods_state[_goods] == BEFORE:
            revert('can not change auction status')

        self._goods_state[_goods] = CANCEL
        self._goods_end_block[_goods] = self.block_height

        _price = self._goods_bid[_goods]
        _owner = self._goods_owner[_goods]

        if not _owner is None:
            self._balance_unlock(_goods, _owner)

        # Event logging
        self.CancelAuction(self.msg.sender, _goods, _auction, _price, _owner, _data)

    @external
    def calculateFee(self, _amount: int):
        # fee sharing
        self.set_fee_sharing_proportion(100)

        # check permission
        self._check_permission(self.msg.sender)

        self._burn(self.msg.sender, _amount)

        self.CalculateFee(self.msg.sender, _amount)
