import json

from . import *
from .. import *
from .libs import *

from iconsdk.wallet.wallet import KeyWallet
from iconsdk.icon_service import IconService
from iconsdk.signed_transaction import SignedTransaction
from iconsdk.providers.http_provider import HTTPProvider
from iconsdk.libs.in_memory_zip import gen_deploy_data_content
from iconsdk.builder.transaction_builder import DeployTransactionBuilder
from tbears.libs.icon_integrate_test import IconIntegrateTestBase, SCORE_INSTALL_ADDRESS

EOA_ZERO = 'hx0000000000000000000000000000000000000000'
PASSWORD = 'donation@CLAP337'


class TestDonation337(IconIntegrateTestBase):
    logger = logging.getLogger('donation337')

    TEST_HTTP_ENDPOINT_URI_V3 = "http://127.0.0.1:9000/api/v3"
    SCORE_PROJECT = os.path.abspath(os.path.join(DIR_PATH, '..'))

    def setUp(self):
        super().setUp()
        self.icon_service = IconService(HTTPProvider(self.TEST_HTTP_ENDPOINT_URI_V3))

        self._generation_key()

        # install SCORE
        self._score_address = self._deploy_score(self.SCORE_PROJECT, self._owner_addrese)['scoreAddress']
        self.logger.info(f'Deploy Score : {self._score_address}...')

    def _generation_key(self):
        self._owner_addrese = KeyWallet.load(f'{DIR_PATH}/../../keystore/owner.json', PASSWORD)
        self._manager_addrese = KeyWallet.load(f'{DIR_PATH}/../../keystore/manager.json', PASSWORD)
        self._user_1_addrese = KeyWallet.load(f'{DIR_PATH}/../../keystore/user_1.json', PASSWORD)
        self._user_2_addrese = KeyWallet.load(f'{DIR_PATH}/../../keystore/user_2.json', PASSWORD)
        self._user_3_addrese = KeyWallet.load(f'{DIR_PATH}/../../keystore/user_3.json', PASSWORD)

    def _deploy_score(
            self,
            _score_path: str,
            _from: KeyWallet,
            _to: str = SCORE_INSTALL_ADDRESS,
            _params: dict = None) -> dict:
        transaction = DeployTransactionBuilder() \
            .from_(_from.get_address()) \
            .to(_to) \
            .step_limit(100_000_000_000) \
            .nid(1) \
            .nonce(100) \
            .content_type('application/zip') \
            .content(gen_deploy_data_content(_score_path)) \
            .params(_params) \
            .build()

        signed_transaction = SignedTransaction(transaction, self._owner_addrese)
        tx_result = self.process_transaction(signed_transaction, self.icon_service)

        self.assertTrue('status' in tx_result)
        if tx_result['status'] != 1:
            self.logger.debug(tx_result)
        self.assertEqual(1, tx_result['status'])
        self.assertTrue('scoreAddress' in tx_result)
        return tx_result

    def test_score_update(self):
        # update SCORE
        tx_result = self._deploy_score(self.SCORE_PROJECT, self._owner_addrese, self._score_address)

        self.assertEqual(self._score_address, tx_result['scoreAddress'])
        self.logger.info(f'Update Score : {self._score_address}...')

    def _manager(self):
        response = call(self.icon_service, self._score_address, self._user_1_addrese, 'manager')
        self.assertEqual(response, self._owner_addrese.address)

        params = dict()
        params['_addr'] = self._manager_addrese.address
        send_tx(self.icon_service, self._score_address, self._owner_addrese, 'addManager', params)

        response = call(self.icon_service, self._score_address, self._user_1_addrese, 'manager')
        self.assertEqual(response, self._manager_addrese.address)

        self.logger.info(f'[SUCCESS] Manager Transaction...')

    def _balance_check(self, amount: int, user_1: int, user_2: int, user_3: int):
        params = dict()
        params['_owner'] = self._user_1_addrese.address
        self.assertEqual(
            amount * user_1,
            int_call(self.icon_service, self._score_address, self._user_1_addrese, 'balanceOf', params)
        )

        params['_owner'] = self._user_2_addrese.address
        self.assertEqual(
            amount * user_2,
            int_call(self.icon_service, self._score_address, self._user_2_addrese, 'balanceOf', params)
        )

        params['_owner'] = self._user_3_addrese.address
        self.assertEqual(
            amount * user_3,
            int_call(self.icon_service, self._score_address, self._user_3_addrese, 'balanceOf', params)
        )

    def _current_balance_check(self, amount: int, user_1: int, user_2: int, user_3: int):
        params = dict()
        params['_owner'] = self._user_1_addrese.address
        self.assertEqual(
            amount * user_1,
            int_call(self.icon_service, self._score_address, self._user_1_addrese, 'currentBalanceOf', params)
        )

        params['_owner'] = self._user_2_addrese.address
        self.assertEqual(
            amount * user_2,
            int_call(self.icon_service, self._score_address, self._user_2_addrese, 'currentBalanceOf', params)
        )

        params['_owner'] = self._user_3_addrese.address
        self.assertEqual(
            amount * user_3,
            int_call(self.icon_service, self._score_address, self._user_3_addrese, 'currentBalanceOf', params)
        )

    def _lock_balance_check(self, amount: int, user_1: int, user_2: int, user_3: int):
        params = dict()
        params['_owner'] = self._user_1_addrese.address
        self.assertEqual(
            amount * user_1,
            int_call(self.icon_service, self._score_address, self._user_1_addrese, 'lockBalanceOf', params)
        )

        params['_owner'] = self._user_2_addrese.address
        self.assertEqual(
            amount * user_2,
            int_call(self.icon_service, self._score_address, self._user_2_addrese, 'lockBalanceOf', params)
        )

        params['_owner'] = self._user_3_addrese.address
        self.assertEqual(
            amount * user_3,
            int_call(self.icon_service, self._score_address, self._user_3_addrese, 'lockBalanceOf', params)
        )

    def _deposit(self):
        decimals = int_call(self.icon_service, self._score_address, self._user_1_addrese, 'decimals')
        amount = 100 * 10 ** decimals

        self._balance_check(amount, 0, 0, 0)

        deposit_id_1 = generate_uuid()
        deposit_id_2 = generate_uuid()
        deposit_id_3 = generate_uuid()

        params = dict()
        params['_order_id'] = deposit_id_1
        params['_owner'] = self._user_1_addrese.address
        params['_balance'] = amount * 2
        params['_type'] =  b'USDT'
        params['_data'] = b'deposit test'
        send_tx(self.icon_service, self._score_address, self._manager_addrese, 'deposit', params)

        params['_order_id'] = deposit_id_2
        params['_owner'] = self._user_2_addrese.address
        params['_balance'] = amount * 3
        params['_type'] = b'USDT'
        params['_data'] = b'deposit test'
        send_tx(self.icon_service, self._score_address, self._manager_addrese, 'deposit', params)

        params['_order_id'] = deposit_id_3
        params['_owner'] = self._user_3_addrese.address
        params['_balance'] = amount * 4
        params['_type'] = b'USDT'
        params['_data'] = b'deposit test'
        send_tx(self.icon_service, self._score_address, self._manager_addrese, 'deposit', params)

        self._balance_check(amount, 2, 3, 4)

        self.logger.info(f'[SUCCESS] Deposit Transaction...')

    def _withdraw(self):
        decimals = int_call(self.icon_service, self._score_address, self._user_1_addrese, 'decimals')
        amount = 100 * 10 ** decimals

        self.withdraw_id_1 = generate_uuid()
        self.withdraw_id_2 = generate_uuid()
        self.withdraw_id_3 = generate_uuid()

        params = dict()
        params['_order_id'] = self.withdraw_id_1
        params['_owner'] = self._user_1_addrese.address
        params['_balance'] = amount
        params['_data'] = b'withdraw test'
        send_tx(self.icon_service, self._score_address, self._user_1_addrese, 'requestWithdraw', params)

        params['_order_id'] = self.withdraw_id_2
        params['_owner'] = self._user_2_addrese.address
        params['_balance'] = amount
        params['_data'] = b'withdraw test'
        send_tx(self.icon_service, self._score_address, self._user_2_addrese, 'requestWithdraw', params)

        params['_order_id'] = self.withdraw_id_3
        params['_owner'] = self._user_3_addrese.address
        params['_balance'] = amount
        params['_data'] = b'withdraw test'
        send_tx(self.icon_service, self._score_address, self._user_3_addrese, 'requestWithdraw', params)

        self._current_balance_check(amount, 1, 2, 3)
        self._lock_balance_check(amount, 1, 1, 1)
        self._balance_check(amount, 2, 3, 4)
        self.logger.info(f'[SUCCESS] Withdraw Transaction...')

    def _confirm_withdraw(self):
        decimals = int_call(self.icon_service, self._score_address, self._user_1_addrese, 'decimals')
        amount = 100 * 10 ** decimals

        params = dict()
        params['_order_id'] = self.withdraw_id_1
        params['_owner'] = self._user_1_addrese.address
        send_tx(self.icon_service, self._score_address, self._manager_addrese, 'confirmWithdraw', params)

        params['_order_id'] = self.withdraw_id_2
        params['_owner'] = self._user_2_addrese.address
        send_tx(self.icon_service, self._score_address, self._manager_addrese, 'confirmWithdraw', params)

        params['_order_id'] = self.withdraw_id_3
        params['_owner'] = self._user_3_addrese.address
        send_tx(self.icon_service, self._score_address, self._manager_addrese, 'confirmWithdraw', params)

        self._current_balance_check(amount, 1, 2, 3)
        self._lock_balance_check(amount, 0, 0, 0)
        self._balance_check(amount, 1, 2, 3)

        self.logger.info(f'[SUCCESS] Confirm Withdraw Transaction...')

    def _add_goods(self) -> dict:
        goods_id = generate_uuid()
        goods_params = dict()
        goods_params['_goods'] = goods_id
        goods_params['_name'] = 'goods'
        goods_params['_url'] = 'https://goods.images.url'
        goods_params['_hash'] = 'QR_Code_image_hash'
        goods_params['_data'] = b'goods test'
        send_tx(self.icon_service, self._score_address, self._manager_addrese, 'addGoods', goods_params)

        params = dict()
        params['_goods'] = goods_id
        response = call(self.icon_service, self._score_address, self._user_1_addrese, 'goods', params)
        self.assertEqual(response['goods'], goods_id)
        self.assertEqual(response['auction'], '-')
        self.assertEqual(response['name'], goods_params['_name'])
        self.assertEqual(response['url'], goods_params['_url'])
        self.assertEqual(response['hash'], goods_params['_hash'])
        self.assertEqual(int(response['bid'], 16), 0)
        self.assertEqual(int(response['state'], 16), BEFORE)
        self.assertEqual(response['owner'], EOA_ZERO)
        self.assertEqual(response['register'], self._manager_addrese.address)
        self.assertEqual(response['confirm'], EOA_ZERO)

        self.logger.info(f'[SUCCESS] Add Goods Transaction...')
        return goods_params

    def _update_goods(self, goods_params: dict):
        goods_params['_name'] = 'goods2'
        goods_params['_url'] = 'https://goods.images.url/images'
        goods_params['_hash'] = 'QR_Code_image_hash2'
        goods_params['_data'] = b'goods update test'
        send_tx(self.icon_service, self._score_address, self._manager_addrese, 'updateGoods', goods_params)

        params = dict()
        params['_goods'] = goods_params['_goods']
        response = call(self.icon_service, self._score_address, self._user_1_addrese, 'goods', params)
        self.assertEqual(response['goods'], goods_params['_goods'])
        self.assertEqual(response['auction'], '-')
        self.assertEqual(response['name'], goods_params['_name'])
        self.assertEqual(response['url'], goods_params['_url'])
        self.assertEqual(response['hash'], goods_params['_hash'])
        self.assertEqual(int(response['bid'], 16), 0)
        self.assertEqual(int(response['state'], 16), BEFORE)
        self.assertEqual(response['owner'], EOA_ZERO)
        self.assertEqual(response['register'], self._manager_addrese.address)
        self.assertEqual(response['confirm'], EOA_ZERO)

        self.logger.info(f'[SUCCESS] Update Goods Transaction...')

    def _add_auction(self, goods_params: dict) -> dict:
        decimals = int_call(self.icon_service, self._score_address, self._user_1_addrese, 'decimals')

        self.auction_id = generate_uuid()
        auction_params = dict()
        auction_params['_goods'] = goods_params['_goods']
        auction_params['_auction'] = self.auction_id
        auction_params['_price'] = 10 * 10 ** decimals
        auction_params['_data'] = b'Auction Test'
        send_tx(self.icon_service, self._score_address, self._manager_addrese, 'addAuction', auction_params)

        self.logger.info(f'[SUCCESS] Add Auction Transaction...')
        return auction_params

    def _auction(self, goods_params: dict, auction_params: dict):
        decimals = int_call(self.icon_service, self._score_address, self._user_1_addrese, 'decimals')
        amount = 100 * 10 ** decimals

        params = dict()
        params['_goods'] = goods_params['_goods']
        params['_auction'] = auction_params['_auction']
        params['_price'] = amount
        params['_data'] = b'bid user 1'
        send_tx(self.icon_service, self._score_address, self._user_1_addrese, 'bidAuction', params)

        self._current_balance_check(amount, 0, 2, 3)
        self._lock_balance_check(amount, 1, 0, 0)
        self._balance_check(amount, 1, 2, 3)

        params = dict()
        params['_goods'] = goods_params['_goods']
        params['_auction'] = auction_params['_auction']
        params['_price'] = amount * 2
        params['_data'] = b'bid user 2'
        send_tx(self.icon_service, self._score_address, self._user_2_addrese, 'bidAuction', params)

        self._current_balance_check(amount, 1, 0, 3)
        self._lock_balance_check(amount, 0, 2, 0)
        self._balance_check(amount, 1, 2, 3)

        params = dict()
        params['_goods'] = goods_params['_goods']
        params['_auction'] = auction_params['_auction']
        params['_price'] = amount * 3
        params['_data'] = b'bid user 3'
        send_tx(self.icon_service, self._score_address, self._user_3_addrese, 'bidAuction', params)

        self._current_balance_check(amount, 1, 2, 0)
        self._lock_balance_check(amount, 0, 0, 3)
        self._balance_check(amount, 1, 2, 3)

        self.logger.info(f'[SUCCESS] Bid Auction Transaction...')

    def _confirm_auction(self, goods_params: dict, auction_params: dict):
        decimals = int_call(self.icon_service, self._score_address, self._user_1_addrese, 'decimals')
        amount = 100 * 10 ** decimals

        params = dict()
        params['_goods'] = goods_params['_goods']
        params['_auction'] = auction_params['_auction']
        send_tx(self.icon_service, self._score_address, self._manager_addrese, 'closeAuction', params)

        params = dict()
        params['_goods'] = goods_params['_goods']
        params['_auction'] = auction_params['_auction']
        params['_data'] = b'auction confirm test'
        send_tx(self.icon_service, self._score_address, self._manager_addrese, 'confirmAuction', params)

        self._balance_check(amount, 1, 2, 0)

        self.logger.info(f'[SUCCESS] Confirm Auction Transaction...')

    def _cancel_auction(self, goods_params: dict, auction_params: dict):
        decimals = int_call(self.icon_service, self._score_address, self._user_1_addrese, 'decimals')
        amount = 10 * 10 ** decimals

        params = dict()
        params['_goods'] = goods_params['_goods']
        params['_auction'] = auction_params['_auction']
        params['_data'] = b'cancel test'
        send_tx(self.icon_service, self._score_address, self._manager_addrese, 'cancelAuction', params)

        params = dict()
        params['_goods'] = goods_params['_goods']
        response = call(self.icon_service, self._score_address, self._user_1_addrese, 'goods', params)
        self.assertEqual(response['goods'],  goods_params['_goods'])
        self.assertEqual(response['auction'], auction_params['_auction'])
        self.assertEqual(response['name'], goods_params['_name'])
        self.assertEqual(response['url'], goods_params['_url'])
        self.assertEqual(response['hash'], goods_params['_hash'])
        self.assertEqual(int(response['bid'], 16), amount)
        self.assertEqual(int(response['state'], 16), CANCEL)
        self.assertEqual(response['owner'], EOA_ZERO)
        self.assertEqual(response['register'], self._manager_addrese.address)
        self.assertEqual(response['confirm'], EOA_ZERO)
        self.logger.info(f'[SUCCESS] Cancel Auction Transaction...')

    def test_work(self):
        self._manager()

        self._deposit()

        self._withdraw()

        self._confirm_withdraw()

        goods_params = self._add_goods()

        self._update_goods(goods_params)

        auction_params = self._add_auction(goods_params)

        self._auction(goods_params, auction_params)

        self._confirm_auction(goods_params, auction_params)

        goods_params = self._add_goods()

        auction_params = self._add_auction(goods_params)

        self._cancel_auction(goods_params, auction_params)
