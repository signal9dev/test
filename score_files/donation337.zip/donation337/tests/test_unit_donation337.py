from hashlib import sha256
from uuid import uuid4
from .. import (
    TAG,
    SYMBOL,
    DECIMALS,
    EOA_ZERO,
    BEFORE,
    CANCEL,
    DOING,
    DONE,
    BID_RATE,
)
from ..donation337 import Donation337
from tbears.libs.scoretest.score_test_case import ScoreTestCase


class TestDonation337(ScoreTestCase):

    def setUp(self):
        super().setUp()
        self.score = self.get_score_instance(Donation337, self.test_account1)

    def test_name(self):
        self.assertEqual(self.score.name(), TAG)

    def test_symbol(self):
        self.assertEqual(self.score.symbol(), SYMBOL)

    def test_decimals(self):
        self.assertEqual(self.score.decimals(), DECIMALS)

    def test_manager(self):
        manager = self.score.manager()
        if not manager:
            self.score.addManager(self.test_account1)
        self.assertEqual(self.score.manager(), self.test_account1)

