# encoding: utf-8
import re
import json
import time
import uuid
import base64
import logging

from datetime import datetime
from iconsdk.icon_service import IconService
from iconsdk.wallet.wallet import KeyWallet
from iconsdk.builder.call_builder import CallBuilder
from iconsdk.signed_transaction import SignedTransaction
from iconsdk.builder.transaction_builder import CallTransactionBuilder

logger = logging.getLogger('donation337')


def gen_tx(addr: KeyWallet, method: str, params: dict, contract_addr: str):
    # Generates an instance of transaction for calling method in SCORE.
    transaction = CallTransactionBuilder() \
        .from_(addr.get_address()) \
        .to(contract_addr) \
        .step_limit(10_000_000) \
        .nid(1) \
        .nonce(100) \
        .method(method) \
        .params(params) \
        .build()

    # Returns the signed transaction object having a signature
    signed_transaction = SignedTransaction(transaction, addr)
    return signed_transaction


def loop_result(icon_service: IconService, txHash: str):
    while True:
        try:
            tx_result = icon_service.get_transaction_result(txHash)
            return tx_result
        except:
            time.sleep(0.3)


def send_tx(
        icon_service: IconService,
        contract_addr: str,
        addr: KeyWallet,
        method: str,
        params: dict = None,
        _debug: bool = False) -> dict:
    if params is None:
        params = {}

    signed_transaction = gen_tx(addr, method, params, contract_addr)

    tx_hash = icon_service.send_transaction(signed_transaction)
    tx_result = loop_result(icon_service, tx_hash)

    if not "status" in tx_result:
        logger.debug(f'@ {method} =====')
        logger.debug(tx_result)
    elif tx_result['status'] != 1:
        logger.debug(f'@ {method} =====')
        logger.debug(tx_result)
    elif _debug:
        print_event_log(tx_result)
    return tx_result


def print_event_log(tx_result: dict):
    for eventlog in tx_result['eventLogs']:
        print_score_address(eventlog['scoreAddress'])

        params = print_method_name(eventlog['indexed'][0])

        logs = eventlog['indexed'][1:]
        for data in eventlog['data']:
            logs.append(data)
        print_params(logs, params)


def print_score_address(scoreAddress: str):
    logger.debug('============================================================')
    logger.debug(scoreAddress)


def print_method_name(method: str) -> list:
    method = re.findall("\w+", method)
    logger.debug(method[0])
    return method[1:]


def print_params(method: list, prams: list):
    for i, _ in enumerate(prams):
        if prams[i] == 'Address':
            logger.debug(f'{i} ::: Address ::: {method[i]}')
        elif prams[i] == 'int':
            logger.debug(f'{i} ::: int ::: {int(method[i], 16)}')
        elif prams[i] == 'bytes':
            data = method[i][2:]
            data = bytearray.fromhex(data)
            data = data.decode('utf-8')
            try:
                data = data.replace("'", '"')
                data = json.loads(data)
                logger.debug(f'{i} ::: bytes -> json ::: {json.dumps(data, indent=4, sort_keys=True)}')
            except:
                logger.debug(f'{i} ::: bytes -> str ::: {data}')
        elif prams[i] == 'str':
            try:
                data = base64.b64decode(method[i])
                logger.debug(f'{i} ::: str ::: {data}')
            except:
                logger.debug(f'{i} ::: str ::: {method[i]}')


def call(
        icon_service: IconService,
        contract_addr: str,
        addr: KeyWallet,
        method: str,
        params: dict = None):
    _call = CallBuilder() \
        .from_(addr.address) \
        .to(contract_addr) \
        .method(method) \
        .params(params) \
        .build()

    # Sends the call request
    request = icon_service.call(_call)
    return request


def int_call(
        icon_service: IconService,
        contract_addr: str,
        addr: KeyWallet,
        method: str,
        params: dict = None) -> int:
    result = call(icon_service, contract_addr, addr, method, params)
    return int(result, 16)


def generate_uuid() -> str:
    return f'{uuid.uuid4()}'


def get_time() -> str:
    return f'{datetime.now()}'
