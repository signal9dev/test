from iconservice import *


class KorDAnchoring(IconScoreBase):

    def __init__(self, db: IconScoreDatabase) -> None:
        super().__init__(db)
        self._anchoring_data = DictDB('anchoring_data', db, value_type=str)
        self._anchoring_block = DictDB('anchoring_block', db, value_type=int)

    def on_install(self) -> None:
        super().on_install()

    def on_update(self) -> None:
        super().on_update()
    
    @external(readonly=True)
    def name(self) -> str:
        return 'KorDAnchoring'

    @external
    def castAnchor(self, _hash: str, _data: str):
        if not self.msg.sender == self.owner:
            revert('transaction sender was not sailor address')
        self._anchoring_data[_hash] = _data
        self._anchoring_block[_hash] = self.block.height

    @external(readonly=True)
    def weighAnchor(self, _hash: str) -> dict:
        response = dict()
        response['data'] = self._anchoring_data[_hash]
        response['block'] = self._anchoring_block[_hash]
        return response
